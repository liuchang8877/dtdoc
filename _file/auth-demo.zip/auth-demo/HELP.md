#开放平台DEMO

说明：

该事例采用springboot 架构开发启动方式 直接运行AuthDemoApplication.java

    具体事例在DemoController.java下
    
    有两个方法 
    
    accessToken方法为sdk使用事例
    
    getaccessToken 为调用开放平台接口使用事例
    
    