package net.newcapec.cloud.controller;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONPObject;
import lombok.extern.slf4j.Slf4j;
import net.newcapec.cloud.auth2.client.auth.Oauth;
import net.newcapec.cloud.auth2.client.exception.OpenCampusException;
import net.newcapec.cloud.auth2.client.model.AccessToken;
import net.newcapec.cloud.auth2.client.request.UserContext;
import net.newcapec.cloud.auth2.client.utils.HttpRequestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.oltu.oauth2.common.message.types.GrantType;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.websocket.server.PathParam;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("openauth")
@Slf4j
public class DemoController {
    @Value("${clientId}")
    private String clientId;

    @Value("${clientSecret}")
    private String clientSecret;
    /**
     * 回调地址
     */
    private String redirectUri="http://192.168.1.106:8880/demo/openauth/accessToken";
    /**
     * 开放平台认证地址
     */
    private String openAuthUrl="http://192.168.113.161:8070/";

    /**
     * sdk获取accessToken
     * @param code
     * @return
     */
    @RequestMapping("/accessToken")
    public void accessToken(HttpServletResponse response,@PathParam("code")String code){
        PrintWriter writer = null;
        response.setHeader("Content-type", "text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        try {
            writer = response.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (StringUtils.isBlank(code)) {
            writer.println("取消授权");
        }
        Oauth oauth = new Oauth(openAuthUrl);
        AccessToken accessToken = null;
        try {
            accessToken =  oauth.getAccessTokenByCode(clientId, clientSecret, redirectUri, code);
        } catch (OpenCampusException e) {
            e.printStackTrace();
        }
        writer.println("accesstoken:"+JSONObject.toJSONString(accessToken));
        UserContext userContext = new UserContext(accessToken.getAccessToken());
        writer.println("用户基本信息:"+userContext.getUserInfo());
        writer.println("实名信息:"+userContext.getRealUserInfo());
    }

    /**
     * 直接调接口调用
     * @param code
     * @return
     */
    @RequestMapping("/getAccessToken")
    public void getaccessToken(HttpServletRequest request, HttpServletResponse response, @PathParam("code")String code){
        PrintWriter writer = null;
        response.setHeader("Content-type", "text/html;charset=UTF-8");
        response.setCharacterEncoding("UTF-8");
        try {
            writer = response.getWriter();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (StringUtils.isBlank(code)) {//TODO 需要根据业务改变参数
            writer.println("取消授权");
        }
        Map<String, Serializable> params = new HashMap<String, Serializable>();
        redirectUri = "http://192.168.1.106:8880/demo/openauth/getAccessToken";
        params.put("code", code);
        params.put("client_id", clientId);
        params.put("client_secret", clientSecret);
        params.put("grant_type", GrantType.AUTHORIZATION_CODE.toString());
        params.put("redirect_uri", redirectUri);
        if (code != null && code.length() > 3) {
            log.debug("获取code:{}", code.replace("^.{1,3}", "*"));
        }
        String accessToken = null;
        try {
            accessToken = HttpRequestUtils.sendHttpRequestForm(openAuthUrl+"access_token", params);
        } catch (IOException e) {
            e.printStackTrace();
        }

        JSONObject tokenJson = JSONObject.parseObject(accessToken);
        String access_token = tokenJson.getString("access_token");
        writer.println("<p>accesstoken信息:"+accessToken+"<p/>");
        writer.println("<p>基本用户信息:"+this.getUserBase(access_token)+"<p/>");
        //实名信息 只有实名认证后才有
        writer.println("实名用户信息"+this.getUserReal(access_token));

        writer.flush();//没有该句也是报一样错.
        writer.close();
    }

    /**
     * 用户基本信息
     * @return
     */
    public String getUserBase(String token){
        String baseUserUrl = "http://192.168.113.161:5008/gateway-auth/api/open/user/base";
        Map<String,String> hearder = new HashMap<String,String>();
        hearder.put("Authorization",token);
        hearder.put("x-deepcloud-from","client");
        String result = null;
        try {
            result = HttpRequestUtils.get(baseUserUrl,hearder).getBody();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 用户实名信息
     * @return
     */
    public String getUserReal(String token){
        String baseUserUrl = "http://192.168.113.161:5008/gateway-auth/api/open/user/rnuser";
        Map<String,String> hearder = new HashMap<String,String>();
        hearder.put("Authorization",token);
        hearder.put("x-deepcloud-from","client");
        String result = null;
        try {
            result = HttpRequestUtils.get(baseUserUrl,hearder).getBody();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }
}
