package net.newcapec.cloud.authdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
